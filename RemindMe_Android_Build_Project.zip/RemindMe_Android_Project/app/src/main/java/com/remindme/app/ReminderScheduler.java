package com.remindme.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;

public final class ReminderScheduler {
    static final String CHANNEL="remindme_reminders_v1";
    private static final String PREF="remindme_alarm_state";
    private static final String KEY="reminders";
    private ReminderScheduler() {}

    static void makeChannel(Context ctx) {
        NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL,"Reminder alerts",NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("RemindMe notifications for scheduled tasks");
        nm.createNotificationChannel(channel);
    }
    static JSONArray saved(Context ctx) {
        try {return new JSONArray(ctx.getSharedPreferences(PREF,0).getString(KEY,"[]"));}
        catch(Exception e) {return new JSONArray();}
    }
    static void replaceAll(Context ctx,String json) {
        try {
            JSONArray next=new JSONArray(json);
            if(next.length()>10000)return;
            JSONArray old=saved(ctx);
            for(int i=0;i<old.length();i++){JSONObject r=old.optJSONObject(i);if(r!=null)cancel(ctx,r.optString("id"));}
            ctx.getSharedPreferences(PREF,0).edit().putString(KEY,json).apply();
            for(int i=0;i<next.length();i++){JSONObject r=next.optJSONObject(i);if(r!=null)schedule(ctx,r,System.currentTimeMillis());}
        } catch(Exception ignored) { }
    }
    static JSONObject find(Context ctx,String id) {
        JSONArray a=saved(ctx);
        for(int i=0;i<a.length();i++){JSONObject r=a.optJSONObject(i);if(r!=null && id.equals(r.optString("id")))return r;}
        return null;
    }
    static void restore(Context ctx) {
        makeChannel(ctx);
        JSONArray list=saved(ctx);
        for(int i=0;i<list.length();i++){
            JSONObject r=list.optJSONObject(i);
            if(r!=null){cancel(ctx,r.optString("id"));schedule(ctx,r,System.currentTimeMillis());}
        }
    }
    private static PendingIntent alarmIntent(Context ctx,String id,int flags) {
        Intent i=new Intent(ctx,ReminderReceiver.class);
        i.setAction("com.remindme.app.ALARM");
        i.setData(Uri.parse("remindme://task/"+Uri.encode(id)));
        i.putExtra("reminder_id",id);
        return PendingIntent.getBroadcast(ctx,id.hashCode(),i,flags|PendingIntent.FLAG_IMMUTABLE);
    }
    static void cancel(Context ctx,String id) {
        if(id==null||id.length()==0)return;
        PendingIntent pending=alarmIntent(ctx,id,PendingIntent.FLAG_NO_CREATE);
        if(pending!=null){((AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE)).cancel(pending);pending.cancel();}
    }
    static long nextOccurrence(JSONObject r,long afterMillis) {
        if(r.optBoolean("done",false))return -1;
        try {
            LocalDate origin=LocalDate.parse(r.getString("date"));
            LocalTime time=LocalTime.parse(r.getString("time"));
            String repeat=r.optString("repeat","none");
            for(int i=0;i<12000;i++) {
                // Always recalculate from original day so Jan 31 -> Feb 28 -> Mar 31.
                LocalDate day;
                switch(repeat){
                    case "none":if(i>0)return -1;day=origin;break;
                    case "daily":day=origin.plusDays(i);break;
                    case "weekly":day=origin.plusWeeks(i);break;
                    case "monthly":day=origin.plusMonths(i);break;
                    case "yearly":day=origin.plusYears(i);break;
                    default:return -1;
                }
                long value=LocalDateTime.of(day,time).atZone(ZoneId.systemDefault())
                        .toInstant().toEpochMilli();
                if(value>afterMillis)return value;
            }
        } catch(Exception ignored) { }
        return -1;
    }
    static void schedule(Context ctx,JSONObject r,long afterMillis) {
        String id=r.optString("id","");if(id.length()==0)return;
        long next=nextOccurrence(r,afterMillis);
        if(next<=0)return;
        AlarmManager am=(AlarmManager)ctx.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi=alarmIntent(ctx,id,PendingIntent.FLAG_UPDATE_CURRENT);
        // Inexact idle-safe alarms do not need restricted exact-alarm permission.
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,pi);
    }
}
