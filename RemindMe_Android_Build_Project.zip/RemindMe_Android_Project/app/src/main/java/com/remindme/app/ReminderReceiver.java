package com.remindme.app;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent) {
        if(intent==null)return;
        String id=intent.getStringExtra("reminder_id");
        if(id==null)return;
        JSONObject reminder=ReminderScheduler.find(context,id);
        if(reminder==null || reminder.optBoolean("done",false))return;
        ReminderScheduler.makeChannel(context);
        // Schedule the next occurrence even if notifications are denied.
        ReminderScheduler.schedule(context,reminder,System.currentTimeMillis()+1000);
        if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!= PackageManager.PERMISSION_GRANTED)return;
        Intent open=new Intent(context,MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content=PendingIntent.getActivity(context,id.hashCode(),open,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(context,ReminderScheduler.CHANNEL)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(reminder.optString("title","Reminder"))
                .setContentText(reminder.optString("notes","It's time for your reminder"))
                .setContentIntent(content).setAutoCancel(true)
                .setCategory(Notification.CATEGORY_REMINDER).build();
        NotificationManager manager=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(id.hashCode(),n);
    }
}
