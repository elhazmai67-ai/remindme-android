package com.remindme.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int NOTIFICATION_REQUEST = 202;
    private static final int FILE_CHOOSER_REQUEST = 203;
    private static final int BACKUP_REQUEST = 204;
    private WebView web;
    private ValueCallback<Uri[]> uploadCallback;
    private String pendingBackup;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(247,248,252));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        ReminderScheduler.makeChannel(this);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(247,248,252));
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
        web.getSettings().setDefaultTextEncodingName("UTF-8");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return true; }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback=callback;
                try {
                    Intent intent=params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception ex) {
                    uploadCallback=null;
                    return false;
                }
            }
        });
        web.addJavascriptInterface(new AndroidBridge(), "RemindMeAndroid");
        setContentView(web);
        try (InputStream in=getAssets().open("www/index.html"); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf=new byte[8192];int n;
            while((n=in.read(buf))!=-1)out.write(buf,0,n);
            String html=out.toString(StandardCharsets.UTF_8.name());
            // Stable HTTPS base origin for localStorage; content itself is bundled, not fetched.
            web.loadDataWithBaseURL("https://app.remindme.local/",html,"text/html","UTF-8",null);
        } catch (Exception e) {
            Toast.makeText(this,"Couldn't load RemindMe",Toast.LENGTH_LONG).show();
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void syncReminders(String json) {
            if (json==null || json.length()>2_000_000) return;
            runOnUiThread(() -> ReminderScheduler.replaceAll(MainActivity.this,json));
        }
        @JavascriptInterface public void requestNotifications() {
            runOnUiThread(() -> {
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
                    // Avoid re-prompting every edit. Settings link may be used after denial.
                    if (!getPreferences(MODE_PRIVATE).getBoolean("permission_asked",false)) {
                        getPreferences(MODE_PRIVATE).edit().putBoolean("permission_asked",true).apply();
                        requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_REQUEST);
                    } else Toast.makeText(MainActivity.this,
                            "Enable RemindMe notifications in Android App Settings",Toast.LENGTH_LONG).show();
                }
            });
        }
        @JavascriptInterface public void saveBackup(String content) {
            if (content==null || content.length()>5_000_000)return;
            runOnUiThread(() -> {
                pendingBackup=content;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE,"RemindMe-backup.json");
                startActivityForResult(i,BACKUP_REQUEST);
            });
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==FILE_CHOOSER_REQUEST) {
            if(uploadCallback!=null) {
                uploadCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
                uploadCallback=null;
            }
        } else if(requestCode==BACKUP_REQUEST) {
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingBackup!=null) {
                try (OutputStream os=getContentResolver().openOutputStream(data.getData())) {
                    if(os==null)throw new Exception("File couldn't be opened");
                    os.write(pendingBackup.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this,"Backup saved",Toast.LENGTH_SHORT).show();
                } catch(Exception ex) { Toast.makeText(this,"Backup failed",Toast.LENGTH_LONG).show(); }
            }
            pendingBackup=null;
        }
    }

    @Override public void onBackPressed() {
        web.evaluateJavascript("if(typeof closeModal==='function')closeModal();if(typeof navigate==='function')navigate('today');",null);
    }
    @Override protected void onDestroy() { if(web!=null)web.destroy(); super.onDestroy(); }
}
