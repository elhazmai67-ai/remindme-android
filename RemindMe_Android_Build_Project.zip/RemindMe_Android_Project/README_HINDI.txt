RemindMe Android 1.0 - build-ready source (APK not compiled here)

Features:
- Approved RemindMe style: Today, Calendar, Categories, Settings
- Add/edit/delete reminders and repeat daily/weekly/monthly/yearly
- Categories: create, rename, delete, choose emoji icon and color
- Category delete retains reminders and moves them to another category
- On-device Android notifications via AlarmManager, including after reboot
- Permission prompt for Android 13+; may be delayed by battery optimization
- Themes, search, completion, snooze, backup/restore

This project uses bundled HTML inside a native Android WebView.
Build with Android Studio or GitHub Actions. Requires Android SDK 35, JDK17,
Gradle 8.9 and internet to download Android Gradle Plugin 8.7.3.

Android notifications use inexact alarms so they MAY be delayed during Doze.
Permission to show notifications must be granted by the user.
The design is not a Play Store release. Debug build is not production signing.
Native device build was not possible in this environment. Verify on phone.

PHONE ONLY BUILD:
1. Create separate PRIVATE GitHub repo 'remindme-android'. Do not mix SnapSort files.
2. Upload the file RemindMe_Android_Build_Project.zip UNEXTRACTED to repository root.
3. In repo create .github/workflows/build-apk.yml and paste
   the content from RemindMe_GitHub_Workflow.yml (outside this archive).
4. GitHub Actions: Build RemindMe Android APK -> open latest green run ->
   Artifacts -> RemindMe-debug-APK -> extract archive -> install app-debug.apk.
5. APK build may require fixes if external dependencies change; read error logs.

App data stays on the device. Export backup before uninstalling. Debug APKs
may have different signing keys across builds so upgrades may not install.


REMIND ME ICON UPDATE – v1.0.1
- Launcher icon: purple bell with check mark.
- Phone launcher display name: Remind Me (with space).
- Android versionCode 2, versionName 1.0.1.
- Source ZIP must be uploaded as RemindMe_Android_Build_Project.zip into the GitHub repo root.
- GitHub workflow must unzip it and build with gradle -p RemindMe_Android_Project :app:assembleDebug.
- Existing debug APK installation may require uninstall if GitHub generated another signing key. BACK UP reminders first.
